package com.h4ll0.multiwall

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Red = Color(0xFFE0262E)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Red,
                    background = Color(0xFF0D0A0A),
                    surface = Color(0xFF191212)
                )
            ) { App() }
        }
    }
}

@Composable
fun App() {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf(Store.all(c)) }
    var pins by remember { mutableStateOf(Store.pinned(c)) }
    var auto by remember { mutableStateOf(Store.auto(c)) }
    var mins by remember { mutableStateOf(Store.mins(c)) }
    var random by remember { mutableStateOf(Store.random(c)) }
    var pinOnly by remember { mutableStateOf(Store.pinOnly(c)) }

    fun refresh() { files = Store.all(c); pins = Store.pinned(c) }
    fun toast(t: String) = Toast.makeText(c, t, Toast.LENGTH_SHORT).show()
    fun schedule() { if (Store.auto(c)) Scheduler.start(c, Store.mins(c)) else Scheduler.stop(c) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        scope.launch {
            withContext(Dispatchers.IO) { uris.forEach { Store.add(c, it) } }
            refresh()
            toast("${uris.size} wallpaper ditambah")
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.statusBarsPadding().padding(horizontal = 12.dp)) {
            Text("Multi Wallpaper", style = MaterialTheme.typography.headlineSmall)
            Text("${files.size} wallpaper, ${pins.size} terkunci", color = Color.Gray)
            Spacer(Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { picker.launch("image/*") }) { Text("+ Tambah") }
                OutlinedButton(onClick = {
                    scope.launch { withContext(Dispatchers.IO) { Setter.next(c) }; toast("Wallpaper diganti") }
                }) { Text("Ganti sekarang") }
            }

            SwitchRow("Ganti otomatis", auto) { auto = it; Store.setAuto(c, it); schedule() }
            if (auto) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15L, 30L, 60L, 180L).forEach { m ->
                        val label = if (m < 60) "$m mnt" else "${m / 60} jam"
                        val pick = { mins = m; Store.setMins(c, m); schedule() }
                        if (mins == m) Button(onClick = pick) { Text(label) }
                        else OutlinedButton(onClick = pick) { Text(label) }
                    }
                }
            }
            SwitchRow("Acak", random) { random = it; Store.setRandom(c, it) }
            SwitchRow("Hanya yang terkunci 🔒", pinOnly) { pinOnly = it; Store.setPinOnly(c, it) }
            Spacer(Modifier.height(8.dp))

            if (files.isEmpty()) {
                Text("Belum ada wallpaper. Tap Tambah, pilih banyak gambar sekaligus.", color = Color.Gray)
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(files, key = { it.name }) { f ->
                    val pinned = f.name in pins
                    val shape = RoundedCornerShape(10.dp)
                    Box(
                        Modifier.aspectRatio(9f / 16f).clip(shape)
                            .then(if (pinned) Modifier.border(2.dp, Red, shape) else Modifier)
                            .clickable {
                                scope.launch {
                                    withContext(Dispatchers.IO) { Setter.setFile(c, f) }
                                    toast("Wallpaper dipasang")
                                }
                            }
                    ) {
                        AsyncImage(f, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        Text(
                            if (pinned) "🔒" else "🔓",
                            Modifier.align(Alignment.TopEnd)
                                .clickable { Store.togglePin(c, f.name); refresh() }.padding(10.dp)
                        )
                        if (!pinned) {
                            Text(
                                "🗑",
                                Modifier.align(Alignment.TopStart)
                                    .clickable { Store.delete(c, f); refresh() }.padding(10.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}
