package com.h4ll0.multiwall

import android.content.Context
import android.net.Uri
import java.io.File

object Store {
    private fun p(c: Context) = c.getSharedPreferences("mw", Context.MODE_PRIVATE)
    private fun dir(c: Context) = File(c.filesDir, "walls").apply { mkdirs() }

    fun all(c: Context): List<File> = dir(c).listFiles()?.sortedBy { it.name } ?: emptyList()

    fun add(c: Context, uri: Uri) {
        val f = File(dir(c), "${System.currentTimeMillis()}_${(0..9999).random()}.img")
        c.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
    }

    fun delete(c: Context, f: File) { f.delete() }

    fun pinned(c: Context): Set<String> = p(c).getStringSet("pin", emptySet())!!.toSet()
    fun togglePin(c: Context, name: String) {
        val s = pinned(c).toMutableSet()
        if (!s.add(name)) s.remove(name)
        p(c).edit().putStringSet("pin", s).apply()
    }

    fun auto(c: Context) = p(c).getBoolean("auto", false)
    fun setAuto(c: Context, v: Boolean) = p(c).edit().putBoolean("auto", v).apply()
    fun mins(c: Context) = p(c).getLong("mins", 15L)
    fun setMins(c: Context, v: Long) = p(c).edit().putLong("mins", v).apply()
    fun random(c: Context) = p(c).getBoolean("rnd", false)
    fun setRandom(c: Context, v: Boolean) = p(c).edit().putBoolean("rnd", v).apply()
    fun pinOnly(c: Context) = p(c).getBoolean("pinOnly", false)
    fun setPinOnly(c: Context, v: Boolean) = p(c).edit().putBoolean("pinOnly", v).apply()
    fun index(c: Context) = p(c).getInt("idx", -1)
    fun setIndex(c: Context, v: Int) = p(c).edit().putInt("idx", v).apply()
}
