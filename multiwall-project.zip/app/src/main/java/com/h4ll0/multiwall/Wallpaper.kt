package com.h4ll0.multiwall

import android.app.WallpaperManager
import android.content.Context
import android.graphics.BitmapFactory
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.io.File
import java.util.concurrent.TimeUnit

object Setter {
    /** Pasang satu file sebagai wallpaper homescreen + lockscreen. */
    fun setFile(c: Context, f: File) {
        val dm = c.resources.displayMetrics
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= dm.widthPixels && o.outHeight / (s * 2) >= dm.heightPixels) s *= 2
        val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return
        WallpaperManager.getInstance(c).setBitmap(
            bmp, null, true, WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
        )
    }

    /** Ganti ke wallpaper berikutnya (urut / acak, boleh cuma yang terkunci). */
    fun next(c: Context) {
        var files = Store.all(c)
        if (Store.pinOnly(c)) files = files.filter { it.name in Store.pinned(c) }
        if (files.isEmpty()) return
        val f = if (Store.random(c)) files.random() else {
            val i = (Store.index(c) + 1) % files.size
            Store.setIndex(c, i)
            files[i]
        }
        setFile(c, f)
    }
}

class WallpaperWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result {
        Setter.next(applicationContext)
        return Result.success()
    }
}

object Scheduler {
    fun start(c: Context, minutes: Long) {
        val req = PeriodicWorkRequestBuilder<WallpaperWorker>(minutes, TimeUnit.MINUTES).build()
        WorkManager.getInstance(c)
            .enqueueUniquePeriodicWork("auto", ExistingPeriodicWorkPolicy.UPDATE, req)
    }
    fun stop(c: Context) = WorkManager.getInstance(c).cancelUniqueWork("auto")
}
